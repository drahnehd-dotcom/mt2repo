import uiScriptLocale
import localeInfo

ROOT = "d:/ymir work/ui/game/"

Y_ADD_POSITION = 0

window = {
	"name" : "TaskBar",

	"x" : 0,
	"y" : SCREEN_HEIGHT - 37,

	"width" : SCREEN_WIDTH,
	"height" : 37,

	"children" :
	(
		{
			"name" : "Base_Board_01",
			"type" : "expanded_image",

			"x" : 263,
			"y" : 0,

			"rect" : (0.0, 0.0, float(SCREEN_WIDTH - 263 - 256) / 256.0, 0.0),

			"image" : "d:/ymir work/ui/pattern/TaskBar_Base.tga"
		},

		{
			"name" : "Gauge_Board",
			"type" : "image",

			"x" : 0,
			"y" : -10 + Y_ADD_POSITION,

			"image" : ROOT + "taskbar/gauge.sub",

			"children" :
			(
				{
					"name" : "RampageGauge",
					"type" : "ani_image",

					"x" : 8,
					"y" : 4,
					"width"  : 40,
					"height" : 40,

					"delay" : 6,

					"images" :
					(
						ROOT + "TaskBar/Discord/discord_00.tga",
						ROOT + "TaskBar/Discord/discord_01.tga",
						ROOT + "TaskBar/Discord/discord_02.tga",
						ROOT + "TaskBar/Discord/discord_03.tga",
						ROOT + "TaskBar/Discord/discord_04.tga",
						ROOT + "TaskBar/Discord/discord_05.tga",
						ROOT + "TaskBar/Discord/discord_06.tga",
						ROOT + "TaskBar/Discord/discord_07.tga",
						ROOT + "TaskBar/Discord/discord_08.tga",
						ROOT + "TaskBar/Discord/discord_09.tga",
						ROOT + "TaskBar/Discord/discord_10.tga",
						ROOT + "TaskBar/Discord/discord_11.tga",
						ROOT + "TaskBar/Discord/discord_12.tga",
						ROOT + "TaskBar/Discord/discord_13.tga",
						ROOT + "TaskBar/Discord/discord_14.tga",
						ROOT + "TaskBar/Discord/discord_15.tga",
						ROOT + "TaskBar/Discord/discord_16.tga",
					)
				},
				{
					"name" : "RampageGauge2",
					"type" : "ani_image",

					"x" : 8,
					"y" : 4,
					"width"  : 40,
					"height" : 40,

					"delay" : 6,

					"images" :
					(
						ROOT + "TaskBar/Discord/discord_00.tga",
						ROOT + "TaskBar/Discord/discord_01.tga",
						ROOT + "TaskBar/Discord/discord_02.tga",
						ROOT + "TaskBar/Discord/discord_03.tga",
						ROOT + "TaskBar/Discord/discord_04.tga",
						ROOT + "TaskBar/Discord/discord_05.tga",
						ROOT + "TaskBar/Discord/discord_06.tga",
						ROOT + "TaskBar/Discord/discord_07.tga",
						ROOT + "TaskBar/Discord/discord_08.tga",
						ROOT + "TaskBar/Discord/discord_09.tga",
						ROOT + "TaskBar/Discord/discord_10.tga",
						ROOT + "TaskBar/Discord/discord_11.tga",
						ROOT + "TaskBar/Discord/discord_12.tga",
						ROOT + "TaskBar/Discord/discord_13.tga",
						ROOT + "TaskBar/Discord/discord_14.tga",
						ROOT + "TaskBar/Discord/discord_15.tga",
						ROOT + "TaskBar/Discord/discord_16.tga",
					)
				},
				{
					"name" : "HPGauge_Board",
					"type" : "window",

					"x" : 59,
					"y" : 14,

					"width" : 95,
					"height" : 11,

					"children" :
					(
						{
							"name" : "HPRecoveryGaugeBar",
							"type" : "bar",

							"x" : 0,
							"y" : 0,
							"width" : 95,
							"height" : 13,
							"color" : 0x55ff0000,
						},
						{
							"name" : "HPGauge",
							"type" : "ani_image",

							"x" : 0,
							"y" : 0,

							"delay" : 6,

							"images" :
							(
								"D:/Ymir Work/UI/Pattern/HPGauge/01.tga",
								"D:/Ymir Work/UI/Pattern/HPGauge/02.tga",
								"D:/Ymir Work/UI/Pattern/HPGauge/03.tga",
								"D:/Ymir Work/UI/Pattern/HPGauge/04.tga",
								"D:/Ymir Work/UI/Pattern/HPGauge/05.tga",
								"D:/Ymir Work/UI/Pattern/HPGauge/06.tga",
								"D:/Ymir Work/UI/Pattern/HPGauge/07.tga",
							),
						},
					),
				},
				{
					"name" : "SPGauge_Board",
					"type" : "window",

					"x" : 59,
					"y" : 24,

					"width" : 95,
					"height" : 11,

					"children" :
					(
						{
							"name" : "SPRecoveryGaugeBar",
							"type" : "bar",

							"x" : 0,
							"y" : 0,
							"width" : 95,
							"height" : 13,
							"color" : 0x550000ff,
						},
						{
							"name" : "SPGauge",
							"type" : "ani_image",

							"x" : 0,
							"y" : 0,

							"delay" : 6,

							"images" :
							(
								"D:/Ymir Work/UI/Pattern/SPGauge/01.tga",
								"D:/Ymir Work/UI/Pattern/SPGauge/02.tga",
								"D:/Ymir Work/UI/Pattern/SPGauge/03.tga",
								"D:/Ymir Work/UI/Pattern/SPGauge/04.tga",
								"D:/Ymir Work/UI/Pattern/SPGauge/05.tga",
								"D:/Ymir Work/UI/Pattern/SPGauge/06.tga",
								"D:/Ymir Work/UI/Pattern/SPGauge/07.tga",
							),
						},
					),
				},
				{
					"name" : "STGauge_Board",
					"type" : "window",

					"x" : 59,
					"y" : 38,

					"width" : 95,
					"height" : 6,

					"children" :
					(
						{
							"name" : "STGauge",
							"type" : "ani_image",

							"x" : 0,
							"y" : 0,

							"delay" : 6,

							"images" :
							(
								"D:/Ymir Work/UI/Pattern/STGauge/01.tga",
								"D:/Ymir Work/UI/Pattern/STGauge/02.tga",
								"D:/Ymir Work/UI/Pattern/STGauge/03.tga",
								"D:/Ymir Work/UI/Pattern/STGauge/04.tga",
								"D:/Ymir Work/UI/Pattern/STGauge/05.tga",
								"D:/Ymir Work/UI/Pattern/STGauge/06.tga",
								"D:/Ymir Work/UI/Pattern/STGauge/07.tga",
							),
						},
					),
				},

			),
		},
		{
			"name" : "EXP_Gauge_Board",
			"type" : "image",

			"x" : 158,
			"y" : 0 + Y_ADD_POSITION,

			"image" : ROOT + "taskbar/exp_gauge.sub",

			"children" :
			(
                { 	
                    "name": "antyexp_window",
                 	"type":"window",
                    "x":2,"y":2,
                    "width" : 100, 
					"height": 100,
                    "children":
                    (
						{
							"name" : "antyexp_img0",
							"type" : "expanded_image",

							"x" : 5,
							"y" : 9,
                            "x_scale":0.55,
                            "y_scale":0.55,

							"image" : "d:/ymir work/ui/slot_off.png",
						},
						{
							"name" : "antyexp_img1",
							"type" : "expanded_image",

							"x" : 30,
							"y" : 9,
                            "x_scale":0.55,
                            "y_scale":0.55,

							"image" : "d:/ymir work/ui/slot_off.png",
						},
						{
							"name" : "antyexp_img2",
							"type" : "expanded_image",

							"x" : 55,
							"y" : 9,
                            "x_scale":0.55,
                            "y_scale":0.55,

							"image" : "d:/ymir work/ui/slot_off.png",
						},
						{
							"name" : "antyexp_img3",
							"type" : "expanded_image",

							"x" : 80,
							"y" : 9,
                            "x_scale":0.55,
                            "y_scale":0.55,

							"image" : "d:/ymir work/ui/slot_off.png",
						},
					),
                },
				{
					"name" : "EXPGauge_01",
					"type" : "expanded_image",

					"x" : 5,
					"y" : 9,

					"image" : ROOT + "TaskBar/EXP_Gauge_Point.sub",
				},
				{
					"name" : "EXPGauge_02",
					"type" : "expanded_image",

					"x" : 30,
					"y" : 9,

					"image" : ROOT + "TaskBar/EXP_Gauge_Point.sub",
				},
				{
					"name" : "EXPGauge_03",
					"type" : "expanded_image",

					"x" : 55,
					"y" : 9,

					"image" : ROOT + "TaskBar/EXP_Gauge_Point.sub",
				},
				{
					"name" : "EXPGauge_04",
					"type" : "expanded_image",

					"x" : 80,
					"y" : 9,

					"image" : ROOT + "TaskBar/EXP_Gauge_Point.sub",
				},
			),
		},

		{
			"name" : "LeftMouseButton",
			"type" : "button",

			"x" : SCREEN_WIDTH/2 - 128,
			"y" : 3 + Y_ADD_POSITION,

			"tooltip_text_new" : localeInfo.TASKBAR_ATTACK,
			"tooltip_text_color" : 0xfff1e6c0,
			"tooltip_x" : 0,
			"tooltip_y" : -35,

			"default_image" : ROOT + "TaskBar/Mouse_Button_Move_01.sub",
			"over_image" : ROOT + "TaskBar/Mouse_Button_Move_02.sub",
			"down_image" : ROOT + "TaskBar/Mouse_Button_Move_03.sub",
		},
		{
			"name" : "RightMouseButton",
			"type" : "button",

			"x" : SCREEN_WIDTH/2 + 128 + 66 + 11,
			"y" : 3 + Y_ADD_POSITION,

			"tooltip_text_new" : localeInfo.TASKBAR_CAMERA,
			"tooltip_text_color" : 0xfff1e6c0,
			"tooltip_x" : 0,
			"tooltip_y" : -35,

			"default_image" : ROOT + "TaskBar/Mouse_Button_Move_01.sub",
			"over_image" : ROOT + "TaskBar/Mouse_Button_Move_02.sub",
			"down_image" : ROOT + "TaskBar/Mouse_Button_Move_03.sub",
		},





		{
			"name" : "CharacterButton",
			"type" : "button",

			"x" : SCREEN_WIDTH - 144,
			"y" : 3 + Y_ADD_POSITION,

			"tooltip_text_new" : uiScriptLocale.TASKBAR_CHARACTER,
			"tooltip_text_color" : 0xfff1e6c0,
			"tooltip_x" : 0,
			"tooltip_y" : -35,

			"default_image" : ROOT + "TaskBar/Character_Button_01.sub",
			"over_image" : ROOT + "TaskBar/Character_Button_02.sub",
			"down_image" : ROOT + "TaskBar/Character_Button_03.sub",
		},
		{
			"name" : "InventoryButton",
			"type" : "button",

			"x" : SCREEN_WIDTH - 110,
			"y" : 3 + Y_ADD_POSITION,

			"tooltip_text_new" : uiScriptLocale.TASKBAR_INVENTORY,
			"tooltip_text_color" : 0xfff1e6c0,
			"tooltip_x" : 0,
			"tooltip_y" : -35,

			"default_image" : ROOT + "TaskBar/Inventory_Button_01.sub",
			"over_image" : ROOT + "TaskBar/Inventory_Button_02.sub",
			"down_image" : ROOT + "TaskBar/Inventory_Button_03.sub",
		},
		{
			"name" : "MessengerButton",
			"type" : "button",

			"x" : SCREEN_WIDTH - 76,
			"y" : 3 + Y_ADD_POSITION,

			"tooltip_text_new" : uiScriptLocale.TASKBAR_MESSENGER,
			"tooltip_text_color" : 0xfff1e6c0,
			"tooltip_x" : 0,
			"tooltip_y" : -35,

			"default_image" : ROOT + "TaskBar/Community_Button_01.sub",
			"over_image" : ROOT + "TaskBar/Community_Button_02.sub",
			"down_image" : ROOT + "TaskBar/Community_Button_03.sub",
		},
		{
			"name" : "SystemButton",
			"type" : "button",

			"x" : SCREEN_WIDTH - 42,
			"y" : 3 + Y_ADD_POSITION,

			"tooltip_text_new" : uiScriptLocale.TASKBAR_SYSTEM,
			"tooltip_text_color" : 0xfff1e6c0,
			"tooltip_x" : 0,
			"tooltip_y" : -35,

			"default_image" : ROOT + "TaskBar/System_Button_01.sub",
			"over_image" : ROOT + "TaskBar/System_Button_02.sub",
			"down_image" : ROOT + "TaskBar/System_Button_03.sub",
		},

		{
			"name" : "quickslot_board",
			"type" : "window",

			"x" : SCREEN_WIDTH/2 - 128 + 32 + 10,
			"y" : 0 + Y_ADD_POSITION,

			"width" : 256 + 14 + 2 + 11,
			"height" : 37,

			"children" :
			(
				{
					"name" : "ExpandButton",
					"type" : "button",

					"x" : 128,
					"y" : 1,
					"tooltip_text_new" : uiScriptLocale.TASKBAR_EXPAND,
					"tooltip_text_color" : 0xfff1e6c0,
					"tooltip_x" : 0,
					"tooltip_y" : -35,

					"default_image" : ROOT + "TaskBar/Chat_Button_01.sub",
					"over_image" : ROOT + "TaskBar/Chat_Button_02.sub",
					"down_image" : ROOT + "TaskBar/Chat_Button_03.sub",
				},
				{
					"name" : "quick_slot_1",
					"type" : "grid_table",

					"start_index" : 0,

					"x" : 0,
					"y" : 3,

					"x_count" : 4,
					"y_count" : 1,
					"x_step" : 32,
					"y_step" : 32,

					"image" : "d:/ymir work/ui/Public/Slot_Base.sub",
					"image_r" : 1.0,
					"image_g" : 1.0,
					"image_b" : 1.0,
					"image_a" : 1.0,

					"children" :
					(
						{ "name" : "slot_1", "type" : "image", "x" : 3, "y" : 3, "image" : "d:/ymir work/ui/game/taskbar/1.sub", },
						{ "name" : "slot_2", "type" : "image", "x" : 35, "y" : 3, "image" : "d:/ymir work/ui/game/taskbar/2.sub", },
						{ "name" : "slot_3", "type" : "image", "x" : 67, "y" : 3, "image" : "d:/ymir work/ui/game/taskbar/3.sub", },
						{ "name" : "slot_4", "type" : "image", "x" : 99, "y" : 3, "image" : "d:/ymir work/ui/game/taskbar/4.sub", },
					),
				},
				{
					"name" : "quick_slot_2",
					"type" : "grid_table",

					"start_index" : 4,

					"x" : 128 + 14,
					"y" : 3,

					"x_count" : 4,
					"y_count" : 1,
					"x_step" : 32,
					"y_step" : 32,

					"image" : "d:/ymir work/ui/Public/Slot_Base.sub",
					"image_r" : 1.0,
					"image_g" : 1.0,
					"image_b" : 1.0,
					"image_a" : 1.0,

					"children" :
					(
						{ "name" : "slot_5", "type" : "image", "x" : 3, "y" : 3, "image" : "d:/ymir work/ui/game/taskbar/f1.sub", },
						{ "name" : "slot_6", "type" : "image", "x" : 35, "y" : 3, "image" : "d:/ymir work/ui/game/taskbar/f2.sub", },
						{ "name" : "slot_7", "type" : "image", "x" : 67, "y" : 3, "image" : "d:/ymir work/ui/game/taskbar/f3.sub", },
						{ "name" : "slot_8", "type" : "image", "x" : 99, "y" : 3, "image" : "d:/ymir work/ui/game/taskbar/f4.sub", },
					),
				},
				{
					"name" : "QuickSlotBoard",
					"type" : "window",

					"x" : 128+14+128+2,
					"y" : 0,
					"width" : 11,
					"height" : 37,
					"children" :
					(
						{
							"name" : "QuickSlotNumberBox",
							"type" : "image",
							"x" : 1,
							"y" : 15,
							"image" : ROOT + "taskbar/QuickSlot_Button_Board.sub",
						},
						{
							"name" : "QuickPageUpButton",
							"type" : "button",
							"tooltip_text_new" : uiScriptLocale.TASKBAR_PREV_QUICKSLOT,
							"tooltip_text_color" : 0xfff1e6c0,
							"tooltip_x" : 0,
							"tooltip_y" : -35,
							"x" : 1,
							"y" : 9,
							"default_image" : ROOT + "TaskBar/QuickSlot_UpButton_01.sub",
							"over_image" : ROOT + "TaskBar/QuickSlot_UpButton_02.sub",
							"down_image" : ROOT + "TaskBar/QuickSlot_UpButton_03.sub",
						},

						{
							"name" : "QuickPageNumber",
							"type" : "image",
							"x" : 3, "y" : 15, "image" : "d:/ymir work/ui/game/taskbar/1.sub",
						},
						{
							"name" : "QuickPageDownButton",
							"type" : "button",
							"tooltip_text_new" : uiScriptLocale.TASKBAR_NEXT_QUICKSLOT,
							"tooltip_text_color" : 0xfff1e6c0,
							"tooltip_x" : 0,
							"tooltip_y" : -35,
							"x" : 1,
							"y" : 24,

							"default_image" : ROOT + "TaskBar/QuickSlot_DownButton_01.sub",
							"over_image" : ROOT + "TaskBar/QuickSlot_DownButton_02.sub",
							"down_image" : ROOT + "TaskBar/QuickSlot_DownButton_03.sub",
						},

					),
				},
			),
		},

	),
}
